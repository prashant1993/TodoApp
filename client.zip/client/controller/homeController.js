app.controller('homeController', function($scope, $http, $auth, $uibModal, $log) {
            $scope.newTodo = {};
            // if (localStorage.getItem("access_token")) {
            //     try {
            //         var user_auth = JSON.parse(localStorage.getItem("access_token"));
            //         if (user_auth.provider === "fb") {
            //             $http.get("https://graph.facebook.com/v2.9/me?fields=name,email,photos,likes,location,cover&access_token=" + user_auth.token).then(function(data) {
            //                 console.log(data.data);
            //             });
            //         }
            //         //Google
            //         else {
            //             console.log(data.data);
            //         }
            //
            //     } catch (e) {
            //
            //     }
            // }
            //to display grid and list view
            $(document).ready(function() {
                $('#list').click(function(event) {
                    event.preventDefault();
                    $('#products .item').addClass('list-group-item');
                });
                $('#grid').click(function(event) {
                    event.preventDefault();
                    $('#products .item').removeClass('list-group-item');
                    $('#products .item').addClass('grid-group-item');
                });
            });

            //sidebar toggle in and toggle out
            $("#menu-toggle").click(function(e) {
                e.preventDefault();
                $("#wrapper").toggleClass("toggled");
            });


            //to read the user
            $scope.readuser = function() {
                $http.get('/userprofile', {
                        headers: {
                            "x-access-token": $auth.getToken
                        }
                    })
                    .then(function(data) {
                        console.log(data.data.user);
                        if (data.data.user.google) {
                            console.log(data.data.user.google);
                            $scope.user = data.data.user.google;

                        } else if (data.data.user.fb) {
                            console.log(data.data.user.fb);
                            $scope.user = data.data.user.fb;

                        } else {
                            console.log(data.data.user.local);
                            $scope.user = data.data.user.local;
                        }
                    })
                    .catch(function(data) {
                        console.log('Error: ' + data);
                    });
            };

            // when landing on the page, get all todos and show them
            $scope.readTodo = function() {
                $http.get('/todo/readTodo', {
                        headers: {
                            "x-access-token": $auth.getToken
                        }
                    })
                    .then(function(data) {
                        $scope.todos = data.data;
                    })
                    .catch(function(data) {
                        console.log('Error: ' + data);
                    });
            };

            // when submitting the add form, send the text to the node API
            $scope.createTodo = function() {
                $http.post('/todo/createTodo', $scope.newTodo, {
                        headers: {
                            "x-access-token": $auth.getToken
                        }
                    })
                    .then(function(data) {
                        $scope.newTodo = {}; // clear the form so our user is ready to enter another
                        $scope.todos = data.data;
                        // console.log(data);
                    })
                    .catch(function(data) {
                        console.log('Error: ' + data);
                    });
            };

            // delete a todo after checking it
            $scope.deleteTodo = function(t_id) {
                $http.delete('/todo/deleteTodo/' + t_id, {
                        headers: {
                            "x-access-token": $auth.getToken
                        }
                    })
                    .then(function(data) {
                        $scope.todos = data.data;
                        console.log(data);
                    })
                    .catch(function(data) {
                        console.log('Error: ' + data);
                    });
            };
            // update a todo after checking it
            // $scope.updateTodo = function(t_id) {
            //   console.log("heeeeeee");
            //         $http.post('/todo/updateTodo/' + t_id, {headers:{"x-access-token":$auth.getToken}})
            //                 .then(function(data) {
            //                         $scope.todos = data;
            //                         console.log(data);
            //                 })
            //                 .catch(function(data) {
            //                         console.log('Error: ' + data);
            //                 });
            // };


            var $ctrl = this;
            // $ctrl.animationsEnabled = true;
            $scope.loadModel = function(data) {
                console.log(data);
                var modalInstance = $uibModal.open({
                    animation: $ctrl.animationsEnabled,
                    templateUrl: 'template/popup.html',
                    controller: function($uibModalInstance, $scope) {
                        $scope.todo = data;
                        //  this.cancel = function () {
                        // console.log('called');
                        //   $uibModalInstanceProvider.dismiss('cancel');
                        // };
                        this.cancel = function() {
                            $uibModalInstance.dismiss();
                        };
                        this.ok = function() {
                            $uibModalInstance.close({});
                        };
                        //
                        // console.log($uibModalInstance);
                        // $('#modal-body').on('keydown',function(e) {
                        //     // trap the return key being pressed
                        //
                        //       console.log('test',e.keyCode);
                        //     if (e.keyCode === 13) {
                        //       console.log('test');
                        //       // insert 2 br tags (if only one br tag is inserted the cursor won't go to the next line)
                        //       document.execCommand('insertHTML', false, '<br><br>');
                        //       // prevent the default behaviour of return key pressed
                        //       return false;
                        //     }
                        //   });
                        $scope.updateTodo = function(todo) {
                            var title = $('#modal-title').html();
                            var description = $('#modal-body').html();
                            console.log(description);
                            try {
                                if (!title || !description) {
                                    throw err;
                                } else {

                                    $scope.todo = {
                                        title: title,
                                        description: description
                                    };
                                }
                                $http.post('/todo/updateTodo/' + todo.t_id, $scope.todo, {
                                        headers: {
                                            "x-access-token": $auth.getToken
                                        }
                                    })
                                    .then(function(data) {
                                        $scope.todo = data.data;
                                        console.log(data);
                                    })
                                    .catch(function(data) {
                                        console.log('Error: ' + data);
                                    });
                            } catch (e) {
                                alert("please enter some text in the field");
                            }

                        };

                    },
                    controllerAs: '$ctrl',
                });

                //     $uibModalInstance.result.then(function(selectedItem) {console.log("test");},
                //         function() {
                //             $log.info('Modal dismissed at: ' + new Date());
                //         });
                 };

                // $ctrl.toggleAnimation = function() {
                //     $ctrl.animationsEnabled = !$ctrl.animationsEnabled;
                // };
            });
